<?php

namespace App\Controllers;

class Education extends BaseController
{
    //Education
    public function how_to_spot_a_forex_scam()
    {
        return view('education/how-to-spot-a-forex-scam');
    }
    
    public function how_to_use_suport_and_resistance()
    {
        return view('education/how-to-use-suport-and-resistance');
    }
    
    public function what_is_forex_fundamental_analysis()
    {
        return view('education/what-is-forex-fundamental-analysis');
    }
    
    public function what_is_forex()
    {
        return view('education/what-is-forex');
    }
    
    public function what_is_technical_analysis()
    {
        return view('education/what-is-technical-analysis');
    }
    
    public function what_should_be_the_trading_psychology()
    {
        return view('education/what-should-be-the-trading-psychology');
    }
    
    public function why_are_technical_indicators_important()
    {
        return view('education/why-are-technical-indicators-important');
    }
    
    public function howto_use_MT5()
    {
        return view('education/howto-use-MT5');
    }
}
