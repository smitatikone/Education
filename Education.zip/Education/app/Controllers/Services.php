<?php

namespace App\Controllers;

class Services extends BaseController
{
    //Services
    public function account_monitoring()
    {
        return view('services/account-monitoring');
    }
    
    public function weekly_mapping()
    {
        return view('services/weekly-mapping');
    }
    
    public function live_tecnical_analysis()
    {
        return view('services/live-tecnical-analysis');
    }
    
    public function community_trading()
    {
        return view('services/community-trading');
    }
}
