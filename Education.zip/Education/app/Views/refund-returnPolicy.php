<?= $this->include('default/header') ?>
<?php //echo view('default/navbar', array('title' => 'Privacy Policy')); ?> 
    <section>
        <div class="container">
            <div class="section-content">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="text-center">Refund &amp; Return Policy </h1><br>
                        <p>Cancellation shall be acceptable only if the Customer requests within 7 days from the time of booking. 20% cancellation charges will be applicable to the total amount of invoice.</p>

<p>The Customer can contact us through e-mail id info@knowledgetradefx.in in case of cancellation and refund.</p>

<p>Force Majeure:</p>

<p>We shall not be liable for any failure to provide our service arising out of compliance with any law, ordinance, regulation, or other governmental action or arising out of acts of God like flood, earthquake, volcanic eruption, interruption of or delay in transportation, or any other similar circumstance beyond our control.</p>

<p>If you have more queries regarding our refund policy please write to us at info@knowledgetradefx.in</p>

                    </div>
                <div>
            </div>
        <div>
    </section>
<?= $this->include('default/footer') ?>