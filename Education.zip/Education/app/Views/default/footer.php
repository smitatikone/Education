
  <!-- Footer -->
  <footer id="footer" class="footer" data-bg-img="<?php echo base_url(); ?>public/assets/images/footer-bg.png" data-bg-color="#152029">
    <div class="container pt-70 pb-40">
      <div class="row">
        <div class="col-sm-6 col-md-3">
          <div class="widget dark">
            <img class="mt-5 mb-20" alt="" src="<?php echo base_url(); ?>public/assets/images/logo-white-footer-new.png">
            <p>111, Atrium center, Khalid bin walid  street, Dubai, UAE.</p>
            <ul class="list-inline mt-5">
              <li class="m-0 pl-10 pr-10"> <i class="fa fa-phone text-theme-colored2 mr-5"></i> <a class="text-gray" href="#">+971 58 891 3150</a> </li>
              <li class="m-0 pl-10 pr-10"> <i class="fa fa-envelope-o text-theme-colored2 mr-5"></i> <a class="text-gray" href="#">info@knowledgetradefx.in</a> </li>
              <li class="m-0 pl-10 pr-10"> <i class="fa fa-globe text-theme-colored2 mr-5"></i> <a class="text-gray" href="#">www.knowledgetradefx.com</a> </li>
            </ul>            
            <ul class="styled-icons icon-sm icon-bordered icon-circled clearfix mt-10">
              <li><a href="https://www.facebook.com/Knowledgetradefx"><i class="fa fa-facebook"></i></a></li>
              <li><a href="https://t.me/Knowledgetradefxcommunity"><i class="fa fa-telegram"></i></a></li>
              <li><a href="https://www.instagram.com/knowledgetradefx/"><i class="fa fa-instagram"></i></a></li>
              <li><a href="https://chat.whatsapp.com/GeJZoH809RU3LFzqK0bbgc"><i class="fa fa-whatsapp"></i></a></li>
            </ul>
          </div>
        </div>
        <div class="col-sm-6 col-md-3">
          <div class="widget dark">
            <h4 class="widget-title line-bottom-theme-colored-2">Useful Links</h4>
            <ul class="angle-double-right list-border">
              <li><a href="<?php echo base_url(); ?>">Home Page</a></li>
              <li><a href="<?php echo base_url(); ?>whyus#">About Us</a></li>
              <li><a href="<?php echo base_url(); ?>">Services</a></li>
              <li><a href="<?php echo base_url("terms-condition"); ?>">Terms and Conditions</a></li>
              <li><a href="#">FAQ</a></li>              
            </ul>
          </div>
        </div>
        <div class="col-sm-6 col-md-3">
          <div class="widget dark">
            <h4 class="widget-title line-bottom-theme-colored-2">Education</h4>
            <ul class="angle-double-right list-border">
                  <li><a href="<?php echo base_url(); ?>what-is-forex">What is Forex? </a></li>
                  <li><a href="<?php echo base_url(); ?>how-to-spot-a-forex-scam">How to Spot a Forex scam?</a></li>
                  <li><a href="<?php echo base_url(); ?>howto-use-MT5">How to use MT5?</a></li>
                  <li><a href="<?php echo base_url(); ?>how-to-use-suport-and-resistance">How to use Support & Resistance?</a></li>
                  <li><a href="<?php echo base_url(); ?>what-is-technical-analysis">What is technical analysis?</a></li>
                  <li><a href="<?php echo base_url(); ?>why-are-technical-indicators-important">Why are technical Indicators Important?</a></li>
                  <li><a href="<?php echo base_url(); ?>what-should-be-the-trading-psychology">What should be the trading Psychology?</a></li>
                  <li><a href="<?php echo base_url(); ?>what-is-forex-fundamental-analysis">What is Forex fundamental analysis?</a></li>        
            </ul>
          </div>
        </div>
        <div class="col-sm-6 col-md-3">
        <div class="widget dark">
            <h4 class="widget-title line-bottom-theme-colored-2">Other Links</h4>
            <ul class="angle-double-right list-border">
              <li><a href="<?php echo base_url(); ?>live_session">Live Session</a></li>
              <li><a href="<?php echo base_url(); ?>webinar">Webinar</a></li>
              <li><a href="<?php echo base_url(); ?>seminar">Seminar</a></li>
              <li><a href="<?php echo base_url(); ?>testimonials">Testimonials</a></li>
            </ul>
          </div>
          <div class="widget dark">
            <h4 class="widget-title line-bottom-theme-colored-2">Opening Hours</h4>
            <div class="opening-hours">
              <ul class="list-border">
                <li class="clearfix"> <span> Mon - Sat :  </span>
                  <div class="value pull-right"> 10.00 am - 07.00 pm </div>
                </li>
                <li class="clearfix"> <span> Sun : </span>
                  <div class="value pull-right text-white closed"> Closed </div>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="footer-bottom" data-bg-color="#2b2d3b">
      <div class="container pt-20 pb-20">
        <div class="row">
          <div class="col-md-6">
            <p class="font-12 text-black-777 m-0 sm-text-center"><a target="_blank" href="#">Copyright © 2022 All Rights reserved by: KTFX</a></p>
          </div>
          <div class="col-md-6 text-right">
            <div class="widget no-border m-0">
              <ul class="list-inline sm-text-center mt-5 font-12">
                <li>
                  <a href="<?php echo base_url("privacy-policy"); ?>" target="_blank">Privacy Policy</a>
                </li>
                <li>|</li>
                <li>
                  <a href="<?php echo base_url("terms-condition"); ?>" target="_blank">Terms and Conditions</a>
                </li>
                <li>|</li>
                <li>
                  <a href="<?php echo base_url("refund-returnPolicy"); ?>" target="_blank">Refund & Return Policy</a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </footer>
  <a class="scrollToTop" href="#"><i class="fa fa-angle-up"></i></a>
</div>
<!-- end wrapper -->

<!-- Footer Scripts -->

<!-- external javascripts -->
<script src="<?php echo base_url(); ?>public/assets/js/jquery-2.2.4.min.js"></script>
<script src="<?php echo base_url(); ?>public/assets/js/jquery-ui.min.js"></script>
<script src="<?php echo base_url(); ?>public/assets/js/bootstrap.min.js"></script>
<!-- JS | jquery plugin collection for this theme -->
<script src="<?php echo base_url(); ?>public/assets/js/jquery-plugin-collection.js"></script>
<!-- JS | Custom script for all pages -->
<script src="<?php echo base_url(); ?>public/assets/js/custom.js"></script>
<script src="<?php echo base_url(); ?>public/assets/js/extra.js"></script>

<!-- Revolution Slider 5.x SCRIPTS -->
<script src="<?php echo base_url(); ?>public/assets/js/revolution-slider/js/jquery.themepunch.tools.min.js"></script>
<script src="<?php echo base_url(); ?>public/assets/js/revolution-slider/js/jquery.themepunch.revolution.min.js"></script>
<script src="<?php echo base_url(); ?>public/assets/js/extra-rev-slider-new.js"></script>

<!-- SLIDER REVOLUTION 5.0 EXTENSIONS  
      (Load Extensions only on Local File Systems ! 
       The following part can be removed on Server for On Demand Loading) -->
<script type="text/javascript" src="http://localhost/Education/public/assets/js/revolution-slider/js/extensions/revolution.extension.actions.min.js"></script>
<script type="text/javascript" src="http://localhost/Education/public/assets/js/revolution-slider/js/extensions/revolution.extension.carousel.min.js"></script>
<script type="text/javascript" src="http://localhost/Education/public/assets/js/revolution-slider/js/extensions/revolution.extension.kenburn.min.js"></script>
<script type="text/javascript" src="http://localhost/Education/public/assets/js/revolution-slider/js/extensions/revolution.extension.migration.min.js"></script>
<script type="text/javascript" src="http://localhost/Education/public/assets/js/revolution-slider/js/extensions/revolution.extension.video.min.js"></script>


</body>


</html>