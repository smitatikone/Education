<!-- Header -->
<header id="header" class="header modern-header modern-header-theme-colored">
    <div class="header-top bg-theme-colored2 sm-text-center">
      <div class="container">
        <div class="row">
          <div class="col-md-8">
            <div class="widget text-white">
              <i class="fa fa-clock-o text-white"></i> Opening Hours:  Mon - Sat : 10.00 am - 7.00 pm, Sunday Closed
            </div>
          </div>
          <div class="col-md-4">
            
            <div class="widget">
              <ul class="list-inline  text-right flip sm-text-center">
                <li class="m-0 pl-10"> <a href="<?php echo base_url(); ?>/public/assets/ajax-load/login-form.html" class="text-white ajaxload-popup"><i class="fa fa-user-o mr-5 text-white"></i> Login /</a> </li>
                <li class="m-0 pl-0 pr-10"> 
                  <a href="<?php echo base_url(); ?>/public/assets/ajax-load/register-form.html" class="text-white ajaxload-popup"><i class="fa fa-edit mr-5 text-white"></i>Register</a> 
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="header-middle p-0 bg-light xs-text-center">
      <div class="container pt-20 pb-20">
        <div class="row">
          <div class="col-xs-12 col-sm-4 col-md-3">
            <div class="widget sm-text-center">
              <i class="fa fa-envelope text-theme-colored font-32 mt-5 mr-sm-0 sm-display-block pull-left flip sm-pull-none"></i>
              <a href="#" class="font-12 text-gray text-uppercase">Mail Us Today</a>
              <h5 class="font-13 text-black m-0">info@knowledgetradefx.in</h5>
            </div>
          </div>
          <div class="col-xs-12 col-sm-4 col-md-6">
            <div class="widget text-center">
              <a class="" href="index-mp-layout1.html"><img src="<?php echo base_url(); ?>/public/assets/images/logo-widenew.png" alt=""></a>
            </div>
          </div>
          <div class="col-xs-12 col-sm-4 col-md-3">
            <div class="widget sm-text-center">
              <i class="fa fa-phone-square text-theme-colored font-32 mt-5 mr-sm-0 sm-display-block pull-left flip sm-pull-none"></i>
              <a href="#" class="font-12 text-gray text-uppercase">Call us for more details</a>
              <h5 class="font-13 text-black m-0"> +971 58 891 3150</h5>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="header-nav">
      <div class="header-nav-wrapper navbascrolltofixed">
        <div class="container">
          <nav id="menuzord" class="menuzord green">
            <ul class="menuzord-menu">
              <li class="<?php if($title == 'Home'){ echo 'active'; } ?>"><a href="<?php echo base_url(); ?>">Home</a></li>
              <li class="<?php if($title == 'Why Us' || $title == 'Contact'){ echo 'active'; } ?>"><a href="#">About Us</a>
                <ul class="dropdown">
                  <li class="active" ><a href="<?php echo base_url(); ?>whyus">Why Us</a></li>                  
                  <li class="active"><a href="<?php echo base_url(); ?>contact">Contact Us</a></li>
                </ul>
              </li>
              <li class="<?php if($title == 'education'){ echo 'active'; } ?>"><a href="#">Education</a>
                <ul class="dropdown">
                  <li><a href="<?php echo base_url(); ?>what-is-forex">What is Forex? </a></li>
                  <li><a href="<?php echo base_url(); ?>how-to-spot-a-forex-scam">How to Spot a Forex scam?</a></li>
                  <li><a href="<?php echo base_url(); ?>howto-use-MT5">How to use MT5?</a></li>
                  <li><a href="<?php echo base_url(); ?>how-to-use-suport-and-resistance">How to use Support & Resistance?</a></li>
                  <li><a href="<?php echo base_url(); ?>what-is-technical-analysis">What is technical analysis?</a></li>
                  <li><a href="<?php echo base_url(); ?>why-are-technical-indicators-important">Why are technical Indicators Important?</a></li>
                  <li><a href="<?php echo base_url(); ?>what-should-be-the-trading-psychology">What should be the trading Psychology?</a></li>
                  <li><a href="<?php echo base_url(); ?>what-is-forex-fundamental-analysis">What is Forex fundamental analysis?</a></li>
                </ul>
              </li>
              <li class="<?php if($title == 'service'){ echo 'active'; } ?>"><a href="#">Services</a>
                <ul class="dropdown">
                  <li><a href="<?php echo base_url(); ?>account-monitoring">ACCOUNT MONITORING</a></li>
                  <li><a href="<?php echo base_url(); ?>weekly-mapping">WEEKLY MAPPING</a></li>
                  <li><a href="<?php echo base_url(); ?>live-tecnical-analysis">LIVE TECHNICAL ANALYSIS</a></li>
                  <li><a href="<?php echo base_url(); ?>community-trading">COMMUNITY TRADING</a></li>
                </ul>
              </li> 
              <!-- <li><a href="javascript:void(0)">Mega Menu</a>
                <div class="megamenu megamenu-bg-img">
                  <div class="megamenu-row">
                    <div class="col3">
                      <h4 class="megamenu-col-title">Latest News:</h4>
                      <div class="widget">
                        <div class="latest-posts">
                          <article class="post media-post clearfix pb-0 mb-10">
                            <a href="blog-single-right-sidebar.html" class="post-thumb"><img alt="" src="http://placehold.it/80x55"></a>
                            <div class="post-right">
                              <h5 class="post-title mt-0 mb-5"><a href="blog-single-right-sidebar.html">Post Title Here</a></h5>
                              <p class="post-date mb-0 font-12">Mar 08, 2015</p>
                            </div>
                          </article>
                          <article class="post media-post clearfix pb-0 mb-10">
                            <a href="blog-single-right-sidebar.html" class="post-thumb"><img alt="" src="http://placehold.it/80x55"></a>
                            <div class="post-right">
                              <h5 class="post-title mt-0 mb-5"><a href="blog-single-right-sidebar.html">Industrial Coatings</a></h5>
                              <p class="post-date mb-0 font-12">Mar 08, 2015</p>
                            </div>
                          </article>
                          <article class="post media-post clearfix pb-0 mb-10">
                            <a href="blog-single-right-sidebar.html" class="post-thumb"><img alt="" src="http://placehold.it/80x55"></a>
                            <div class="post-right">
                              <h5 class="post-title mt-0 mb-5"><a href="blog-single-right-sidebar.html">Storefront Installations</a></h5>
                              <p class="post-date mb-0 font-12">Mar 08, 2015</p>
                            </div>
                          </article>
                          <article class="post media-post clearfix pb-0 mb-10">
                            <a href="blog-single-right-sidebar.html" class="post-thumb"><img alt="" src="http://placehold.it/80x55"></a>
                            <div class="post-right">
                              <h5 class="post-title mt-0 mb-5"><a href="blog-single-right-sidebar.html">Industrial Coatings</a></h5>
                              <p class="post-date mb-0 font-12">Mar 08, 2015</p>
                            </div>
                          </article>
                        </div>
                      </div>
                    </div>
                    <div class="col3">
                      <h4 class="megamenu-col-title"><strong>Featured News:</strong></h4>
                      <article class="post clearfix">
                        <div class="entry-header">
                          <div class="post-thumb"> <img class="img-responsive" src="<?php echo base_url(); ?>/public/assets/images/blog/1.jpg" alt=""> </div>
                        </div>
                        <div class="entry-content">
                          <p class="">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna et sed aliqua</p>
                          <a class="btn btn-dark btn-theme-colored" href="#">read more..</a> </div>
                      </article>
                    </div>
                    <div class="col3">
                      <h4 class="megamenu-col-title">Promotional Offer:</h4>
                      <img src="<?php echo base_url(); ?>/public/assets/images/megamenu/megamenu-sale-off.jpg" alt="">
                    </div>
                    <div class="col3">
                      <h4 class="megamenu-col-title">Quick Links:</h4>
                      <ul class="list-dashed list-icon">
                        <li><a href="#">Privacy Policy</a></li>
                        <li><a href="#">Disclaimer</a></li>
                        <li><a href="#">Terms of Use</a></li>
                        <li><a href="#">Copyright Notice</a></li>
                      </ul>
                    </div>
                  </div>
                </div>
              </li> -->
              <li class="<?php if($title == 'session'){ echo 'active'; } ?>"><a href="#">Session</a>
                <ul class="dropdown">
                  <li><a href="<?php echo base_url(); ?>live_session">Live Session</a></li>
                  <li><a href="<?php echo base_url(); ?>webinar">Webinar</a></li>
                  <li><a href="<?php echo base_url(); ?>seminar">Seminar</a></li>
                </ul>
              </li> 
              <li class="<?php if($title == 'testimonials'){ echo 'active'; } ?>"><a href="<?php echo base_url(); ?>testimonials">Free Tools</a></li>
              <!-- <li><a href="<?php //echo base_url(); ?>contact">Contact Us</a></li> -->
            </ul>
            <!-- <ul class="pull-right sm-pull-nonelist-inline nav-side-icon-list">
              <li>
                <a href="#fullscreen-search-form" id="fullscreen-search-btn"><i class="search-icon text-theme-colored2 fa fa-search"></i></a>
                <div id="fullscreen-search-form">
                  <button type="button" class="close">×</button>
                  <form>
                    <input type="search" value="" placeholder="Search keywords(s)" />
                    <button type="submit"><i class="search-icon fa fa-search"></i></button>
                  </form>
                </div>
              </li>
            </ul> -->
          </nav>
        </div>
      </div>
    </div>
  </header>

  
  