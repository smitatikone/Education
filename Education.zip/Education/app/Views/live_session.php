<?= $this->include('default/header') ?>
<?php echo view('default/navbar', array('title' => 'session')); ?> 

    <!-- Start main-content -->
<div class="main-content">
    <!-- Section: inner-header -->
    <section class="inner-header divider layer-overlay overlay-theme-colored-7" data-bg-img="<?php echo base_url(); ?>public/assets/images/bg/bg1.jpg" style="background-image: url(&quot;<?php echo base_url(); ?>public/assets/images/bg/bg1.jpg&quot;);">
      <div class="container pt-120 pb-60">
        <!-- Section Content -->
        <div class="section-content">
          <div class="row"> 
            <div class="col-md-6">
              <h2 class="text-white font-36">Live Session </h2>
              <ol class="breadcrumb text-left mt-10 white">
                <li><a href="#">Home</a></li>
                <li class="active">Live Session</li>
              </ol>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section id="team">
      <div class="container">
        <div class="section-title text-center">
          <div class="row">
            <div class="col-md-10 col-md-offset-1">
              <h2 class="text-uppercase line-bottom-double-line-centered mt-0">Live <span class="text-theme-colored2">Session</span></h2>
              <p>"Experience the extraordinary power of live trading sessions, exclusively brought to you by KnowledgeTradeFX - the unrivaled platform that has created a monopoly in India! Unleash your potential and seize this golden opportunity to access the most exhilarating sessions in the industry. Don't wait another moment - click here now and step into a world where every trade becomes a thrilling adventure!"</p>
            </div>
            <button data-loading-text="Please wait..." class="btn btn-flat btn-dark btn-theme-colored2 mt-5" type="submit">CLICK HERE</button>
          </div>
        </div>
      </div>
    </section>

<?= $this->include('default/footer') ?>