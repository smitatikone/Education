<?= $this->include('default/header') ?>
<?php echo view('default/navbar', array('title' => 'Home')); ?> 

<!-- Start main-content -->
  <div class="main-content">

    <section id="home" class="divider">
      <div class="container-fluid p-0">
        <!-- START REVOLUTION SLIDER 5.0.7 -->
        <div id="rev_slider_home_wrapper" class="rev_slider_wrapper fullwidthbanner-container" data-alias="news-gallery34" style="margin:0px auto;background-color:#ffffff;padding:0px;margin-top:0px;margin-bottom:0px;">
          <!-- START REVOLUTION SLIDER 5.0.7 fullwidth mode -->
          <div id="rev_slider_home" class="rev_slider fullwidthabanner" style="display:none;" data-version="5.0.7">
            <img src="<?php echo base_url(); ?>public/assets/images/bg/bg13.jpg" alt="" data-bgposition="top 40%" data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="10" class="rev-slidebg" data-no-retina>
          </div>
        </div>
      </div>
    </section>
    <!-- Section: home-boxed -->
    <section>
      <div class="container pb-0">
        <div class="section-content">
          <div class="row"  data-margin-top="-150px">
            <div class="col-md-4">
              <div class="icon-box iconbox-border border-theme-colored2 bg-theme-colored text-center p-40 mb-sm-50">
                <a class="icon icon-lg icon-top bg-theme-colored2 icon-rounded icon-border-effect effect-rounded" href="#">
                  <i class="fa fa-book text-white"></i>
                </a>
                <h3 class="icon-box-title mt-50 text-white">Online Course</h3>
                <p class="text-white mb-20">Lorem ipsum dolor sit amet adipisi elit molestias non nulla placeat odio dolor amet  dicta alias.</p>
              </div>
            </div>
            <div class="col-md-4">
              <div class="icon-box text-center p-40 mb-sm-50 border-2px border-theme-colored2" data-bg-img="<?php echo base_url(); ?>public/assets/images/about/a1.jpg">
                <div>
                <span class="typed-text-carousel font-20 text-white" data-speed="50" data-back_delay="600" data-loop="true">
                <span class="font-25">Become a Profitable Trader</span>
                </span>
                <br>
                <h2 class="font-15 text-white">Join our 7-day ultimate trading & investment webinar and take your trading skills to new heights. </h2>
                <br><br><br> <a href="#" class="btn btn-default text-theme-colored mt-5 mb-10">Signup Now</a>
                </div>
              </div>
            </div>
            <div class="col-md-4">
              <div class="icon-box iconbox-border border-theme-colored2 bg-theme-colored text-center p-40 mb-sm-50">
                <a class="icon icon-lg icon-top bg-theme-colored2 icon-rounded icon-border-effect effect-rounded" href="#">
                  <i class="fa fa-user text-white"></i>
                </a>
                <h3 class="icon-box-title mt-50 text-white">Expart Teachers</h3>
                <p class="text-white mb-20">Lorem ipsum dolor sit amet adipisi elit molestias non nulla placeat odio dolor amet  dicta alias.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- Section: about -->
    <section class="">
      <div class="container pt-sm-0 pb-0">
        <div class="row">
          <div class="col-md-5">
            <h3 class="text-theme-colored mt-0 mt-sm-30 mb-0">Welcome To</h3>
            <h2 class="text-theme-colored2 mt-0">Knowledge Trade FX</h2>
              <div class="event media mt-20 mb-10 no-bg no-border">
                <div class="media-body pl-10">
                  <div class="event-content pull-left flip">
                    <h1 class="event-title media-heading mt-15"><a href="#">About</a></h1>
                    <p style="font-size: 18px;">Our aim is for Trading Education to become the go-to place for anyone looking for reliable information about how to trade the financial market and invest their money wisely. To achieve this ambition, it's important to us that our content remains free to access.</p>
                  </div>
                </div><br>
                <a class="btn btn-theme-colored2 btn-sm text-white" href="<?php echo base_url(); ?>whyus"> View Details</a>
              </div>
          </div>
          <div class="col-md-7">
            <div class="row">
              <div class="col-sm-6 mt-30">
               <img src="<?php echo base_url(); ?>public/assets/images/about/dc1.png" alt="">
              </div>
              <div class="col-sm-6">
               <div class="p-30 mt-0 bg-theme-colored">
                <h3 class="title-pattern mt-0"><span class="text-white">Request <span class="text-theme-color-2">Information</span></span></h3>
                <!-- Appilication Form Start-->
                <form id="reservation_form" name="reservation_form" class="reservation-form mt-20" method="post" action="http://thememascot.net/demo/personal/s/studypro/j/demo/includes/reservation.php">
                  <div class="row">
                    <div class="col-sm-12">
                      <div class="form-group mb-20">
                        <input placeholder="Enter Name" type="text" id="reservation_name" name="reservation_name" required="" class="form-control">
                      </div>
                    </div>
                    <div class="col-sm-12">
                      <div class="form-group mb-20">
                        <input placeholder="Email" type="text" id="reservation_email" name="reservation_email" class="form-control" required="">
                      </div>
                    </div>
                    <div class="col-sm-12">
                      <div class="form-group mb-20">
                        <div class="styled-select">
                          <input placeholder="Mobile" type="text" id="reservation_mob" name="reservation_mob" class="form-control" required="">
                        </div>
                      </div>
                    </div>
                    <div class="col-sm-12">
                      <div class="form-group">
                        <textarea placeholder="Enter Message" rows="3" class="form-control required" name="form_message" id="form_message" aria-required="true"></textarea>
                      </div>
                    </div>
                    <div class="col-sm-12">
                      <div class="form-group mb-0 mt-10">
                        <input name="form_botcheck" class="form-control" type="hidden" value="">
                        <button type="submit" class="btn btn-colored btn-theme-colored2 text-white btn-lg btn-block" data-loading-text="Please wait...">Submit Request</button>
                      </div>
                    </div>
                  </div>
                </form>
                <!-- Application Form End-->
                </div>
              </div>              
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- Section: info-boxes -->
    <section class="">
      <div class="container pt-0 pt-sm-30">
        <div class="section-content">
          <div class="row equal-height-inner home-boxes">
            <div class="col-sm-12 col-md-3 pl-0 pl-sm-15 pr-0 pr-sm-15 sm-height-auto mt-sm-0 wow fadeInLeft animation-delay1">
              <div class="sm-height-auto bg-theme-colored">
                <div class="text-center pt-30 pb-30">
                  <i class="fa fa-user text-white font-64"></i>
                  <h4 class="text-uppercase mt-20"><a href="#" class="text-white">24 Hours Service</a></h4>
                </div>
              </div>
            </div>
            <div class="col-sm-12 col-md-3 pl-0 pl-sm-15 pr-0 pr-sm-15 sm-height-auto mt-sm-0 wow fadeInLeft animation-delay2">
              <div class="sm-height-auto bg-theme-colored2-lighter2">
                <div class="text-center pt-30 pb-30">
                  <i class="fa fa-comments-o text-white font-64"></i>
                  <h4 class="text-uppercase mt-20"><a href="#" class="text-white">Online Help</a></h4>
                </div>
              </div>
            </div>
            <div class="col-sm-12 col-md-3 pl-0 pl-sm-15 pr-0 pr-sm-15 sm-height-auto mt-sm-0 wow fadeInLeft animation-delay3">
              <div class="sm-height-auto bg-theme-colored-darker3">
                <div class="text-center pt-30 pb-30">
                  <i class="fa fa-cc-paypal text-white font-64"></i>
                  <h4 class="text-uppercase mt-20"><a href="#" class="text-white">Online Payment</a></h4>
                </div>
              </div>
            </div>
            <div class="col-sm-12 col-md-3 pl-0 pl-sm-15 pr-0 pr-sm-15 sm-height-auto mt-sm-0 wow fadeInLeft animation-delay4">
              <div class="sm-height-auto bg-theme-colored2-lighter2">
                <div class="text-center pt-30 pb-30">
                  <i class="fa fa-mobile text-white font-64"></i>
                  <h4 class="text-uppercase mt-20"><a href="#" class="text-white">Call +971 58 891 3150</a></h4>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- Section: Education -->
    <section id="blog" class="bg-silver-light">
      <div class="container">
        <div class="section-title text-center">
          <div class="row">
            <div class="col-md-10 col-md-offset-1">
              <h2 class="text-uppercase line-bottom-double-line-centered mt-0">Education</span></h2>
              <!-- <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Rem autem voluptatem obcaecati! <br>ipsum dolor sit Rem autem voluptatem obcaecati</p> -->
            </div>
          </div>
        </div>
        <div class="section-content">
          <div class="row">
            <div class="col-md-12">
              <div class="owl-carousel-3col owl-nav-top" data-nav="true">
                <div class="item">
                  <article class="post clearfix campaign mb-30">
                    <div class="entry-header">
                      <div class="post-thumb thumb"> 
                        <img src="<?php echo base_url(); ?>public/assets/images/blog/1.jpg" alt="" class="img-responsive img-fullwidth"> 
                      </div>                    
                    </div>
                    <div class="entry-content p-20 bg-white">
                      <div class="entry-meta media mt-0 mb-10">
                        <div class="media-body pl-0">
                          <div class="event-content pull-left flip">
                            <h3 class="entry-title text-white text-uppercase m-0 mt-5"><a href="<?php echo base_url(); ?>what-is-forex">What is Forex?</a></h3>
                          </div>
                        </div>
                      </div>
                      <a class="btn btn-theme-colored2 btn-sm text-white" href="<?php echo base_url(); ?>what-is-forex"> View Details</a>
                    </div>
                  </article>
                </div>
                <div class="item">
                  <article class="post clearfix campaign mb-30">
                    <div class="entry-header">
                      <div class="post-thumb thumb"> 
                        <img src="<?php echo base_url(); ?>public/assets/images/blog/1.jpg" alt="" class="img-responsive img-fullwidth"> 
                      </div>                    
                    </div>
                    <div class="entry-content p-20 bg-white">
                      <div class="entry-meta media mt-0 mb-10">
                        <div class="media-body pl-0">
                          <div class="event-content pull-left flip">
                            <h3 class="entry-title text-white text-uppercase m-0 mt-5"><a href="<?php echo base_url(); ?>how-to-spot-a-forex-scam">How to Spot a Forex scam?</a></h3>
                          </div>
                        </div>
                      </div>
                      <a class="btn btn-theme-colored2 btn-sm text-white" href="<?php echo base_url(); ?>how-to-spot-a-forex-scam"> View Details</a>
                    </div>
                  </article>
                </div>

                <div class="item">
                  <article class="post clearfix campaign mb-30">
                    <div class="entry-header">
                      <div class="post-thumb thumb"> 
                        <img src="<?php echo base_url(); ?>public/assets/images/blog/1.jpg" alt="" class="img-responsive img-fullwidth"> 
                      </div>                    
                    </div>
                    <div class="entry-content p-20 bg-white">
                      <div class="entry-meta media mt-0 mb-10">
                        <div class="media-body pl-0">
                          <div class="event-content pull-left flip">
                            <h3 class="entry-title text-white text-uppercase m-0 mt-5"><a href="<?php echo base_url(); ?>howto-use-MT5">How to use MT5?</a></h3>
                          </div>
                        </div>
                      </div>
                      <a class="btn btn-theme-colored2 btn-sm text-white" href="<?php echo base_url(); ?>howto-use-MT5"> View Details</a>
                    </div>
                  </article>
                </div>
                <div class="item">
                  <article class="post clearfix campaign mb-30">
                    <div class="entry-header">
                      <div class="post-thumb thumb"> 
                        <img src="<?php echo base_url(); ?>public/assets/images/blog/1.jpg" alt="" class="img-responsive img-fullwidth"> 
                      </div>                    
                    </div>
                    <div class="entry-content p-20 bg-white">
                      <div class="entry-meta media mt-0 mb-10">
                        <div class="media-body pl-0">
                          <div class="event-content pull-left flip">
                            <h3 class="entry-title text-white text-uppercase m-0 mt-5"><a href="<?php echo base_url(); ?>how-to-use-suport-and-resistance">How to use Support & Resistance?</a></h3>
                          </div>
                        </div>
                      </div>
                      <a class="btn btn-theme-colored2 btn-sm text-white" href="<?php echo base_url(); ?>how-to-use-suport-and-resistance"> View Details</a>
                    </div>
                  </article>
                </div>
                <div class="item">
                  <article class="post clearfix campaign mb-30">
                    <div class="entry-header">
                      <div class="post-thumb thumb"> 
                        <img src="<?php echo base_url(); ?>public/assets/images/blog/1.jpg" alt="" class="img-responsive img-fullwidth"> 
                      </div>                    
                    </div>
                    <div class="entry-content p-20 bg-white">
                      <div class="entry-meta media mt-0 mb-10">
                        <div class="media-body pl-0">
                          <div class="event-content pull-left flip">
                            <h3 class="entry-title text-white text-uppercase m-0 mt-5"><a href="<?php echo base_url(); ?>what-is-technical-analysis">What is technical analysis?</a></h3>
                          </div>
                        </div>
                      </div>
                      <a class="btn btn-theme-colored2 btn-sm text-white" href="<?php echo base_url(); ?>what-is-technical-analysis"> View Details</a>
                    </div>
                  </article>
                </div>
                <div class="item">
                  <article class="post clearfix campaign mb-30">
                    <div class="entry-header">
                      <div class="post-thumb thumb"> 
                        <img src="<?php echo base_url(); ?>public/assets/images/blog/1.jpg" alt="" class="img-responsive img-fullwidth"> 
                      </div>                    
                    </div>
                    <div class="entry-content p-20 bg-white">
                      <div class="entry-meta media mt-0 mb-10">
                        <div class="media-body pl-0">
                          <div class="event-content pull-left flip">
                            <h3 class="entry-title text-white text-uppercase m-0 mt-5"><a href="<?php echo base_url(); ?>why-are-technical-indicators-important">Why are technical Indicators Important?</a></h3>
                          </div>
                        </div>
                      </div>
                      <a class="btn btn-theme-colored2 btn-sm text-white" href="<?php echo base_url(); ?>why-are-technical-indicators-important"> View Details</a>
                    </div>
                  </article>
                </div>
                <div class="item">
                  <article class="post clearfix campaign mb-30">
                    <div class="entry-header">
                      <div class="post-thumb thumb"> 
                        <img src="<?php echo base_url(); ?>public/assets/images/blog/1.jpg" alt="" class="img-responsive img-fullwidth"> 
                      </div>                    
                    </div>
                    <div class="entry-content p-20 bg-white">
                      <div class="entry-meta media mt-0 mb-10">
                        <div class="media-body pl-0">
                          <div class="event-content pull-left flip">
                            <h3 class="entry-title text-white text-uppercase m-0 mt-5"><a href="<?php echo base_url(); ?>what-should-be-the-trading-psychology">What should be the trading Psychology?</a></h3>
                          </div>
                        </div>
                      </div>
                      <a class="btn btn-theme-colored2 btn-sm text-white" href="<?php echo base_url(); ?>what-should-be-the-trading-psychology"> View Details</a>
                    </div>
                  </article>
                </div>
                <div class="item">
                  <article class="post clearfix campaign mb-30">
                    <div class="entry-header">
                      <div class="post-thumb thumb"> 
                        <img src="<?php echo base_url(); ?>public/assets/images/blog/1.jpg" alt="" class="img-responsive img-fullwidth"> 
                      </div>                    
                    </div>
                    <div class="entry-content p-20 bg-white">
                      <div class="entry-meta media mt-0 mb-10">
                        <div class="media-body pl-0">
                          <div class="event-content pull-left flip">
                            <h3 class="entry-title text-white text-uppercase m-0 mt-5"><a href="<?php echo base_url(); ?>what-is-forex-fundamental-analysis">What is Forex fundamental analysis?</a></h3>
                          </div>
                        </div>
                      </div>
                      <a class="btn btn-theme-colored2 btn-sm text-white" href="<?php echo base_url(); ?>what-is-forex-fundamental-analysis"> View Details</a>
                    </div>
                  </article>
                </div>
                
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>


    <!-- Divider: Funfact -->
    <section class="divider parallax layer-overlay overlay-theme-colored-7" data-bg-img="<?php echo base_url(); ?>public/assets/images/bg/bg5.jpg" data-parallax-ratio="0.7">
      <div class="container">
        <div class="section-content text-center">
          <div class="row">
            <div class="col-md-12">
              <h2 class="mt-0 mb-50 text-white">Some important facts</h2>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-xs-12 col-sm-6 col-md-3 mb-md-50">
            <div class="funfact text-center">
              <i class="pe-7s-smile mt-5 text-theme-colored2"></i>
                <div class="odometer-animate-number text-white font-weight-600 font-48" data-value="1000" data-theme="minimal">1K+</div>
              <h5 class="text-white text-uppercase mb-0">Happy Customers</h5>
            </div>
          </div>
          <div class="col-xs-12 col-sm-6 col-md-3 mb-md-50">
            <div class="funfact text-center">
              <i class="pe-7s-note2 mt-5 text-theme-colored2"></i>
                <div class="odometer-animate-number text-white font-weight-600 font-48" data-value="500+" data-theme="minimal">500+</div>
              <h5 class="text-white text-uppercase mb-0">Accounts</h5>
            </div>
          </div>
          <div class="col-xs-12 col-sm-6 col-md-3 mb-md-50">
            <div class="funfact text-center">
              <i class="pe-7s-users mt-5 text-theme-colored2"></i>
                <div class="odometer-animate-number text-white font-weight-600 font-48" data-value="100+" data-theme="minimal">100+</div>
              <h5 class="text-white text-uppercase mb-0">Employess</h5>
            </div>
          </div>
          <div class="col-xs-12 col-sm-6 col-md-3 mb-md-0">
            <div class="funfact text-center">
              <i class="pe-7s-cup mt-5 text-theme-colored2"></i>
                <div class="odometer-animate-number text-white font-weight-600 font-48" data-value="14+" data-theme="minimal">14+</div>
              <h5 class="text-white text-uppercase mb-0">Contries</h5>
            </div>
          </div>
        </div>
      </div>
    </section>

    
    <!-- Section: Services -->
    <section id="Services" class="bg-silver-light">
      <div class="container pb-40">
        <div class="section-title text-center">
          <div class="row">
            <div class="col-md-12">
              <h2 class="text-uppercase line-bottom-double-line-centered mt-0"><span class="text-theme-colored2">Services</span></h2>
            </div>
          </div>
        </div>
        <div class="row mtli-row-clearfix">
          <div class="owl-carousel-3col">
            <div class="item">
              <div class="course-single-item style2 text-center mb-40">
                <div class="course-thumb">
                  <img class="img-fullwidth" alt="" src="<?php echo base_url(); ?>public/assets/images/course/sm1.jpg">
                </div>
                <div class="course-details bg-white border-1px clearfix p-15 pt-15">
                  <div class="course-top-part">
                    <a href="<?php echo base_url(); ?>account-monitoring"><h4 class="line-bottom-centered mt-20">Account monitoring</h4></a>
                  </div>
                  <a class="btn btn-theme-colored2 btn-sm text-white" href="<?php echo base_url(); ?>account-monitoring"> View Details</a>
                </div>
              </div>
            </div>
            <div class="item">
              <div class="course-single-item style2 text-center mb-40">
                <div class="course-thumb">
                  <img class="img-fullwidth" alt="" src="<?php echo base_url(); ?>public/assets/images/course/sm2.jpg">
                </div>
                <div class="course-details bg-white border-1px clearfix p-15 pt-15">
                  <div class="course-top-part">
                    <a href="<?php echo base_url(); ?>weekly-mapping"><h4 class="line-bottom-centered mt-20">Weekly Mapping</h4></a>
                  </div>
                  <a class="btn btn-theme-colored2 btn-sm text-white" href="<?php echo base_url(); ?>weekly-mapping"> View Details</a>
                </div>
              </div>
            </div>
            <div class="item">
              <div class="course-single-item style2 text-center mb-40">
                <div class="course-thumb">
                  <img class="img-fullwidth" alt="" src="<?php echo base_url(); ?>public/assets/images/course/sm3.jpg">
                </div>
                <div class="course-details bg-white border-1px clearfix p-15 pt-15">
                  <div class="course-top-part">
                    <a href="<?php echo base_url(); ?>live-tecnical-analysis"><h4 class="line-bottom-centered mt-20">Live Technical Analysis</h4></a>
                  </div>
                  <a class="btn btn-theme-colored2 btn-sm text-white" href="<?php echo base_url(); ?>live-tecnical-analysis"> View Details</a>
                </div>
              </div>
            </div>
            <div class="item">
              <div class="course-single-item style2 text-center mb-40">
                <div class="course-thumb">
                  <img class="img-fullwidth" alt="" src="<?php echo base_url(); ?>public/assets/images/course/sm4.jpg">
                </div>
                <div class="course-details bg-white border-1px clearfix p-15 pt-15">
                  <div class="course-top-part">
                    <a href="<?php echo base_url(); ?>community-trading"><h4 class="line-bottom-centered mt-20">Community Trading</h4></a>
                  </div>
                  <a class="btn btn-theme-colored2 btn-sm text-white" href="<?php echo base_url(); ?>community-trading"> View Details</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    
    <!-- Section: Stories -->
    <section id="event" class="bg-silver-light">
      <div class="container">
        <div class="section-content">
          <div class="row">
          <h2 class="line-bottom mt-0">Success <span class="text-theme-colored2">Stories</span></h2>
            <div class="col-md-4">              
              <div class="row">
                <div class="col-md-12">
                  <div class="box-hover-effect play-button">
                    <div class="effect-wrapper">
                      <div class="thumb">
                        <img class="img-fullwidth" src="<?php echo base_url(); ?>public/assets/images/about/successStory.png" alt="project">
                      </div>
                      <div class="overlay-shade bg-theme-colored"></div>
                      <div class="video-button"></div>
                      <a class="hover-link" data-lightbox-gallery="youtube-video" href="https://youtube.com/shorts/9AkHZ5w6o8U?feature=share  " title="Youtube Video">Youtube Video</a>
                    </div>
                  </div>             
                </div>
              </div>
            </div>
            <div class="col-md-4">
              <div class="row">
                <div class="col-md-12">
                  <div class="box-hover-effect play-button">
                    <div class="effect-wrapper">
                      <div class="thumb">
                        <img class="img-fullwidth" src="<?php echo base_url(); ?>public/assets/images/about/successStory.png" alt="project">
                      </div>
                      <div class="overlay-shade bg-theme-colored"></div>
                      <div class="video-button"></div>
                      <a class="hover-link" data-lightbox-gallery="youtube-video" href="https://youtube.com/shorts/4yFphNN2TjM" title="Youtube Video">Youtube Video</a>
                    </div>
                  </div>             
                </div>
              </div>
            </div>
            <div class="col-md-4">
              <div class="row">
                <div class="col-md-12">
                  <div class="box-hover-effect play-button">
                    <div class="effect-wrapper">
                      <div class="thumb">
                        <img class="img-fullwidth" src="<?php echo base_url(); ?>public/assets/images/about/successStory2.jpg" alt="project">
                      </div>
                      <div class="overlay-shade bg-theme-colored"></div>
                      <div class="video-button"></div>
                      <a class="hover-link" data-lightbox-gallery="youtube-video" href="https://youtu.be/0RRjTdeGl5E" title="Youtube Video">Youtube Video</a>
                    </div>
                  </div>             
                </div>
              </div>
            </div>
          </div>
          <div class="row mt-20">
          <h2 class="line-bottom mt-0"></h2>
            <div class="col-md-4">
              <div class="icon-box bg-white left media border-1px border-theme-colored2 bg-hover-theme-colored mb-30 p-30 pb-20"> <a class="media-left pull-left flip" href="#"><i class="fa fa-television text-theme-colored2"></i></a>
                <div class="media-body">
                  <h4 class="media-heading heading">LIVE SESSION </h4>
                  <a class="btn btn-theme-colored2 btn-lg text-white" style="padding: 5px;" href="<?php echo base_url(); ?>live_session"> View Details</a>
                </div>
              </div>
            </div>
            <div class="col-md-4">
              <div class="icon-box bg-white left media border-1px border-theme-colored2 bg-hover-theme-colored mb-30 p-30 pb-20"> <a class="media-left pull-left flip" href="#"><i class="fa fa-podcast text-theme-colored2"></i></a>
                <div class="media-body">
                  <h4 class="media-heading heading">WEBINAR</h4>
                  <a class="btn btn-theme-colored2 btn-lg text-white" style="padding: 5px;" href="<?php echo base_url(); ?>webinar"> View Details</a>
                </div>
              </div>
            </div>
            <div class="col-md-4">
              <div class="icon-box bg-white left media border-1px border-theme-colored2 bg-hover-theme-colored mb-30 p-30 pb-20"> <a class="media-left pull-left flip" href="#"><i class="fa fa-laptop text-theme-colored2"></i></a>
                <div class="media-body">
                  <h4 class="media-heading heading">SEMINAR</h4>
                  <a class="btn btn-theme-colored2 btn-lg text-white" style="padding: 5px;" href="<?php echo base_url(); ?>seminar"> View Details</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- Divider: testimonials -->
    <section class="divider layer-overlay overlay-theme-colored-5" data-bg-img="<?php echo base_url(); ?>public/assets/images/bg/team-bg1.png">
      <div class="container pt-60 pb-60">
        <div class="row">
          <div class="col-md-8 col-md-offset-2">
            <h2 class="line-bottom-double-line-centered text-white text-center mt-0 mb-0">Learn The Art of Trading and Earn $$$</h2>
              <div class="text-center mb-30"><i class="icon_quotations font-72 text-gray-lightgray"></i></div>
            <div class="owl-carousel-1col" data-dots="true">
              <div class="item">
                <div class="testimonial-wrapper text-center">
                  
                  <div class="content pt-10">
                    <p class="lead text-white">Dominate the art of trading and learn how to think and act like a BIG investor. Take advantage of our FREE 7-Days ultimate forex trading webinar for beginners. Register for more info!</p>
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="testimonial-wrapper text-center">
                  
                  <div class="content pt-10">
                    <p class="lead text-white">Dominate the art of trading and learn how to think and act like a BIG investor. Take advantage of our FREE 7-Days ultimate forex trading webinar for beginners. Register for more info!</p>
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="testimonial-wrapper text-center">
                  
                  <div class="content pt-10">
                    <p class="lead text-white">Dominate the art of trading and learn how to think and act like a BIG investor. Take advantage of our FREE 7-Days ultimate forex trading webinar for beginners. Register for more info!</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    
    <!-- Divider: Clients -->
    <section class="clients bg-theme-colored2">
      <div class="container pt-10 pb-0">
        <div class="row">
          <div class="col-md-12">
            <!-- Section: Clients -->
            <div class="owl-carousel-6col text-center">
              <div class="item"> <a href="#"><img src="<?php echo base_url(); ?>public/assets/images/clients/w1.png" alt=""></a></div>
              <div class="item"> <a href="#"><img src="<?php echo base_url(); ?>public/assets/images/clients/w2.png" alt=""></a></div>
              <div class="item"> <a href="#"><img src="<?php echo base_url(); ?>public/assets/images/clients/w3.png" alt=""></a></div>
              <div class="item"> <a href="#"><img src="<?php echo base_url(); ?>public/assets/images/clients/w4.png" alt=""></a></div>
              <div class="item"> <a href="#"><img src="<?php echo base_url(); ?>public/assets/images/clients/w5.png" alt=""></a></div>
              <div class="item"> <a href="#"><img src="<?php echo base_url(); ?>public/assets/images/clients/w6.png" alt=""></a></div>
              <div class="item"> <a href="#"><img src="<?php echo base_url(); ?>public/assets/images/clients/w3.png" alt=""></a></div>
              <div class="item"> <a href="#"><img src="<?php echo base_url(); ?>public/assets/images/clients/w4.png" alt=""></a></div>
              <div class="item"> <a href="#"><img src="<?php echo base_url(); ?>public/assets/images/clients/w5.png" alt=""></a></div>
              <div class="item"> <a href="#"><img src="<?php echo base_url(); ?>public/assets/images/clients/w6.png" alt=""></a></div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>
  <!-- end main-content -->

  <?= $this->include('default/footer') ?>