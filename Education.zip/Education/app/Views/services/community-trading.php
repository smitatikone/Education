<?= $this->include('default/header') ?>
<?php echo view('default/navbar', array('title' => 'service')); ?> 

 <!-- Start main-content -->
 <div class="main-content">
    <!-- Section: inner-header -->
    <section class="inner-header divider layer-overlay overlay-theme-colored-7" data-bg-img="<?php echo base_url(); ?>/public/assets/images/bg/bg1.jpg">
      <div class="container pt-120 pb-60">
        <!-- Section Content -->
        <div class="section-content">
          <div class="row"> 
            <div class="col-md-6">
              <h2 class="text-white font-36">Community Trading</h2>
              <ol class="breadcrumb text-left mt-10 white">
                <li><a href="#">Home</a></li>
                <li><a href="#">Services</a></li>
                <li class="active">Community Trading</li>
              </ol>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section id="team">
      <div class="container">
        <div class="section-title text-left">
          <div class="row">
            <div class="col-md-10 col-md-offset-1">
              <!-- <h2 class="line-bottom mt-0">COMMUNITY TRADING</span></h2> -->
              <p>"Welcome to our community trading service, where forex traders come together to unlock the power of collective intelligence. Our platform provides a vibrant community of like-minded individuals who share a passion for forex trading.</p>
              <p>By joining our community, you gain access to a wealth of trading knowledge, insights, and support. Engage in lively discussions, share trade ideas, and learn from experienced traders who have successfully navigated the forex market. Our platform serves as a hub for collaboration, empowering you to enhance your trading skills and make informed decisions.</p>
              <p>Tap into the collective wisdom of our community, where traders freely exchange valuable information, discuss market trends, and explore diverse trading strategies. Discover new perspectives that can help you uncover hidden opportunities and gain a competitive edge in the forex market. </p>
              <p>Our community trading service fosters a sense of camaraderie, offering a supportive environment for both novice and seasoned traders. Connect with fellow traders, exchange feedback, and receive guidance that can fuel your trading journey. No longer feel isolated in your trading activities—find motivation, encouragement, and a network of individuals who share your ambitions. </p>
              <p>However, remember to approach the information shared within the community with a critical mindset. While our platform facilitates knowledge sharing, it's crucial to conduct your own analysis and research before making any trading decisions. Exercise caution, and leverage the insights gained from the community to complement your trading strategies. </p>
              <p>Join our community trading service today and unlock the power of collaboration in forex trading. Together, we can navigate the dynamic world of forex and strive for greater success in our trading endeavors." </p>

            </div>
          </div>
        </div>
      </div>
    </section>

<?= $this->include('default/footer') ?>