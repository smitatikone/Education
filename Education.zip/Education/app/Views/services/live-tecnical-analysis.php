<?= $this->include('default/header') ?>
<?php echo view('default/navbar', array('title' => 'service')); ?> 

    <!-- Start main-content -->
  <div class="main-content">
    <!-- Section: inner-header -->
    <section class="inner-header divider layer-overlay overlay-theme-colored-7" data-bg-img="<?php echo base_url(); ?>/public/assets/images/bg/bg1.jpg">
      <div class="container pt-120 pb-60">
        <!-- Section Content -->
        <div class="section-content">
          <div class="row"> 
            <div class="col-md-6">
              <h2 class="text-white font-36">Live Technical Analysis</h2>
              <ol class="breadcrumb text-left mt-10 white">
                <li><a href="#">Home</a></li>
                <li><a href="#">Services</a></li>
                <li class="active">Live Technical Analysis</li>
              </ol>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section id="team">
      <div class="container">
        <div class="section-title text-left">
          <div class="row">
            <div class="col-md-10 col-md-offset-1">
            <!-- <h2 class="text-uppercase line-bottom-double-line-centered mt-0">Welcome to our Forex Trading <span class="text-theme-colored2"> Weekly Mapping Service!</span></h2> -->
              <p>"Welcome to <strong>KNOWLEDGETRADEFX</strong>, where we offer an exceptional live technical analysis service for forex trading. Our platform provides you with real-time market insights and expert analysis to empower your trading decisions.</p>
              <p>With our live technical analysis service, you gain access to a comprehensive range of tools and techniques that enable you to make informed trading choices. Our team of experienced analysts continuously monitor the market, analyzing price charts, indicators, and patterns as they unfold in real-time.</p>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section id="event" class="bg-silver-light">
      <div class="container">
        <div class="section-content">
          <div class="row">
            <div class="col-md-12">
              <h2 class="line-bottom mt-0">Key <span class="text-theme-colored2">Points</span></h2>
              <p>Real-Time Market Insights: Stay ahead of the game with our real-time analysis. We provide you with up-to-the-minute data and expert interpretations, ensuring you have the latest information at your fingertips.</p>
            </div>
          </div>
          <div class="row mt-20">
            <div class="col-md-6">
              <div class="icon-box bg-white left media border-1px border-theme-colored2 bg-hover-theme-colored mb-30 p-30 pb-20"> <a class="media-left pull-left flip" href="#"><i class="fa fa-book text-theme-colored2"></i></a>
                <div class="media-body">
                  <h4 class="media-heading heading">Comprehensive Chart Analysis</h4>
                  <p>Our platform offers a wide range of chart types, including candlestick charts, line charts, and more. These charts are accompanied by powerful technical indicators and tools to help you identify trends, patterns, and potential trade opportunities.</p>
                </div>
              </div>
            </div>
            <div class="col-md-6">
              <div class="icon-box bg-white left media border-1px border-theme-colored2 bg-hover-theme-colored mb-30 p-30 pb-20"> <a class="media-left pull-left flip" href="#"><i class="fa fa-graduation-cap text-theme-colored2"></i></a>
                <div class="media-body">
                  <h4 class="media-heading heading">Expert-Driven Analysis</h4>
                  <p>Our team of skilled analysts leverages their expertise and experience to provide you with valuable insights. They analyze price movements, identify key support and resistance levels, and interpret complex indicators, assisting you in making well-informed trading decisions.</p>
                </div>
              </div>
            </div>
            <div class="col-md-4">
              <div class="icon-box bg-white left media border-1px border-theme-colored2 bg-hover-theme-colored mb-30 p-30 pb-20"> <a class="media-left pull-left flip" href="#"><i class="fa fa-university text-theme-colored2"></i></a>
                <div class="media-body">
                  <h4 class="media-heading heading">Trading Signals and Alerts</h4>
                  <p>Receive real-time trading signals and alerts based on our technical analysis. These notifications highlight potential entry and exit points, allowing you to take advantage of profitable opportunities promptly.</p>
                </div>
              </div>
            </div>
            <div class="col-md-4">
              <div class="icon-box bg-white left media border-1px border-theme-colored2 bg-hover-theme-colored mb-30 p-30 pb-20"> <a class="media-left pull-left flip" href="#"><i class="fa fa-university text-theme-colored2"></i></a>
                <div class="media-body">
                  <h4 class="media-heading heading">Integration with Trading Platforms</h4>
                  <p>Seamlessly integrate our live technical analysis service with your preferred trading platform. This ensures a smooth experience, enabling you to execute trades efficiently while utilizing our analysis tools.</p>
                </div>
              </div>
            </div>
            <div class="col-md-4">
              <div class="icon-box bg-white left media border-1px border-theme-colored2 bg-hover-theme-colored mb-30 p-30 pb-20"> <a class="media-left pull-left flip" href="#"><i class="fa fa-university text-theme-colored2"></i></a>
                <div class="media-body">
                  <h4 class="media-heading heading">Educational Resources</h4>
                  <p>Enhance your trading knowledge with our educational resources. We offer tutorials, articles, and webinars that cover various aspects of technical analysis, helping you sharpen your skills and deepen your understanding of the markets.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <section id="team">
      <div class="container">
        <div class="section-title text-left">
          <div class="row">
            <div class="col-md-10 col-md-offset-1">
              <p>Our live technical analysis service is designed to empower traders of all levels, from beginners to seasoned professionals. Whether you are looking for short-term trades or long-term investments, our comprehensive analysis and real-time insights will assist you in making smarter trading decisions.</p>
              <p>Start maximizing your trading potential today by joining our website and gaining access to our cutting-edge live technical analysis service. Explore the markets with confidence and take your forex trading to new heights".</p>
            </div>
          </div>
        </div>
      </div>
    </section>
<?= $this->include('default/footer') ?>