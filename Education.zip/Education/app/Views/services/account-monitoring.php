<?= $this->include('default/header') ?>
<?php echo view('default/navbar', array('title' => 'service')); ?> 

    <!-- Start main-content -->
  <div class="main-content">
    <!-- Section: inner-header -->
    <section class="inner-header divider layer-overlay overlay-theme-colored-7" data-bg-img="<?php echo base_url(); ?>/public/assets/images/bg/bg1.jpg">
      <div class="container pt-120 pb-60">
        <!-- Section Content -->
        <div class="section-content">
          <div class="row"> 
            <div class="col-md-6">
              <h2 class="text-white font-36">Account Monitoring</h2>
              <ol class="breadcrumb text-left mt-10 white">
                <li><a href="#">Home</a></li>
                <li><a href="#">Services</a></li>
                <li class="active">Account Monitoring</li>
              </ol>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section id="event" class="bg-silver-light">
      <div class="container">
        <div class="section-content">
          <div class="row">
            <div class="col-md-12">
              <h2 class="line-bottom mt-0">Account <span class="text-theme-colored2">Monitoring</span></h2>
            </div>
          </div>
          <div class="row mt-20">
            <div class="col-md-4">
              <div class="icon-box bg-white left media border-1px border-theme-colored2 bg-hover-theme-colored mb-30 p-30 pb-20"> <a class="media-left pull-left flip" href="#"><i class="fa fa-book text-theme-colored2"></i></a>
                <div class="media-body">
                  <h4 class="media-heading heading">Profit and Loss (P&L) Analysis</h4>
                  <p>Gain valuable insights into the profitability of your trades with our comprehensive P&L analysis.</p>
                </div>
              </div>
            </div>
            <div class="col-md-4">
              <div class="icon-box bg-white left media border-1px border-theme-colored2 bg-hover-theme-colored mb-30 p-30 pb-20"> <a class="media-left pull-left flip" href="#"><i class="fa fa-graduation-cap text-theme-colored2"></i></a>
                <div class="media-body">
                  <h4 class="media-heading heading">Equity Curve Analysis</h4>
                  <p>Track the growth or decline of your account balance over time using our advanced equity curve analysis tools.</p>
                </div>
              </div>
            </div>
            <div class="col-md-4">
              <div class="icon-box bg-white left media border-1px border-theme-colored2 bg-hover-theme-colored mb-30 p-30 pb-20"> <a class="media-left pull-left flip" href="#"><i class="fa fa-university text-theme-colored2"></i></a>
                <div class="media-body">
                  <h4 class="media-heading heading">Risk Management Evaluation</h4>
                  <p>Ensure effective risk management by evaluating and adjusting your risk strategies based on our expert recommendations.</p>
                </div>
              </div>
            </div>
            <div class="col-md-4">
              <div class="icon-box bg-white left media border-1px border-theme-colored2 bg-hover-theme-colored mb-30 p-30 pb-20"> <a class="media-left pull-left flip" href="#"><i class="fa fa-university text-theme-colored2"></i></a>
                <div class="media-body">
                  <h4 class="media-heading heading">Trade Analysis</h4>
                  <p>Analyze individual trades in detail to identify patterns, strengths, and weaknesses, enabling you to make more informed trading decisions.</p>
                </div>
              </div>
            </div>
            <div class="col-md-4">
              <div class="icon-box bg-white left media border-1px border-theme-colored2 bg-hover-theme-colored mb-30 p-30 pb-20"> <a class="media-left pull-left flip" href="#"><i class="fa fa-university text-theme-colored2"></i></a>
                <div class="media-body">
                  <h4 class="media-heading heading">Performance Metrics</h4>
                  <p>Access key performance metrics such as win rate and drawdown to assess the overall performance of your trading system.</p>
                </div>
              </div>
            </div>
            <div class="col-md-4">
              <div class="icon-box bg-white left media border-1px border-theme-colored2 bg-hover-theme-colored mb-30 p-30 pb-20"> <a class="media-left pull-left flip" href="#"><i class="fa fa-university text-theme-colored2"></i></a>
                <div class="media-body">
                  <h4 class="media-heading heading">Journaling and Documentation</h4>
                  <p>Keep a well-organized trading journal to document your trades and learn from past experiences, ultimately improving your decision-making process.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <section id="team">
      <div class="container">
        <div class="section-title text-center">
          <div class="row">
            <div class="col-md-10 col-md-offset-1">
              <p>Our trading account monitoring service provides you with the necessary tools and insights to enhance your trading performance. With our expertise, you can make informed decisions and optimize your trading strategies for better profitability.</p>
            </div>
          </div>
        </div>
      </div>
    </section>
<?= $this->include('default/footer') ?>