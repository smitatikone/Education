<?= $this->include('default/header') ?>
<?php echo view('default/navbar', array('title' => 'service')); ?> 

    <!-- Start main-content -->
  <div class="main-content">
    <!-- Section: inner-header -->
    <section class="inner-header divider layer-overlay overlay-theme-colored-7" data-bg-img="<?php echo base_url(); ?>/public/assets/<?php echo base_url(); ?>public/assets/images/bg/bg1.jpg">
      <div class="container pt-120 pb-60">
        <!-- Section Content -->
        <div class="section-content">
          <div class="row"> 
            <div class="col-md-6">
              <h2 class="text-white font-36">Weekly Mapping</h2>
              <ol class="breadcrumb text-left mt-10 white">
                <li><a href="#">Home</a></li>
                <li><a href="#">Services</a></li>
                <li class="active">Weekly Mapping</li>
              </ol>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section id="team">
      <div class="container">
        <div class="section-title text-center">
          <div class="row">
            <div class="col-md-10 col-md-offset-1">
            <h2 class="text-uppercase line-bottom-double-line-centered mt-0">Welcome to our Forex Trading <span class="text-theme-colored2"> Weekly Mapping Service!</span></h2>
              <p>Gain a broader perspective and make informed trading decisions with our Weekly Mapping service. We specialize in analyzing the Forex market on a weekly timeframe, providing you with valuable insights to maximize your trading potential.</p>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- Section: Courses -->
    <section id="courses" class="bg-silver-light">
      <div class="container pb-40">
        <div class="section-title text-center">
          <div class="row">
            <div class="col-md-12">
                <h5 class="text-uppercase line-bottom-double-line-centered mt-0">Key Features of Our Weekly Mapping Service</h5>
              </div>
          </div>
        </div>
        <div class="row mtli-row-clearfix">
          <div class="owl-carousel-3col">
            <div class="item">
              <div class="course-single-item style2 text-center mb-40">
                <div class="course-thumb">
                  <img class="img-fullwidth" alt="" src="<?php echo base_url(); ?>public/assets/images/course/sm1.jpg">
                </div>
                <div class="course-details bg-white border-1px clearfix p-15 pt-15">
                  <div class="course-top-part">
                    <a href="#"><h4 class="line-bottom-centered mt-20">Comprehensive Support and Resistance Levels</h4></a>
                </div>
                  <p class="course-description mt-5">Our expert analysts identify crucial price levels that have historically influenced market behavior, giving you an edge in determining potential entry and exit points.</p>
                </div>
              </div>
            </div>
            <div class="item">
              <div class="course-single-item style2 text-center mb-40">
                <div class="course-thumb">
                  <img class="img-fullwidth" alt="" src="<?php echo base_url(); ?>public/assets/images/course/sm2.jpg">
                </div>
                <div class="course-details bg-white border-1px clearfix p-15 pt-15">
                  <div class="course-top-part">
                    <a href="#"><h4 class="line-bottom-centered mt-20">Accurate Trend Analysis</h4></a>     
                  </div>
                  <p class="course-description mt-5">Stay in sync with the market's dominant direction. We carefully analyze price action and trend indicators to help you align your trades with the prevailing trend, increasing your chances of success.</p>
                </div>
              </div>
            </div>
            <div class="item">
              <div class="course-single-item style2 text-center mb-40">
                <div class="course-thumb">
                  <img class="img-fullwidth" alt="" src="<?php echo base_url(); ?>public/assets/images/course/sm3.jpg">
                </div>
                <div class="course-details bg-white border-1px clearfix p-15 pt-15">
                  <div class="course-top-part">
                    <a href="#"><h4 class="line-bottom-centered mt-20">Pattern Recognition</h4></a>
                  </div>
                  <p class="course-description mt-5">Unlock the power of chart patterns. Our team is skilled at identifying formations like triangles, head and shoulders, double tops/bottoms, and more, allowing you to spot potential reversals or continuations.</p>
                </div>
              </div>
            </div>
            <div class="item">
              <div class="course-single-item style2 text-center mb-40">
                <div class="course-thumb">
                  <img class="img-fullwidth" alt="" src="<?php echo base_url(); ?>public/assets/images/course/sm4.jpg">
                </div>
                <div class="course-details bg-white border-1px clearfix p-15 pt-15">
                  <div class="course-top-part">
                    <a href="#"><h4 class="line-bottom-centered mt-20">Fibonacci Analysis</h4></a>
                  </div>
                  <p class="course-description mt-5">Discover hidden opportunities with Fibonacci retracements and extensions. We apply these key levels to significant price swings, helping you identify areas of support or resistance for better trade management.</p>
                </div>
              </div>
            </div>
            <div class="item">
              <div class="course-single-item style2 text-center mb-40">
                <div class="course-thumb">
                  <img class="img-fullwidth" alt="" src="<?php echo base_url(); ?>public/assets/images/course/sm5.jpg">
                </div>
                <div class="course-details bg-white border-1px clearfix p-15 pt-15">
                  <div class="course-top-part">
                    <a href="#"><h4 class="line-bottom-centered mt-20">Market Structure Insights</h4></a>
                  </div>
                  <p class="course-description mt-5">: Understand the bigger picture. Our analysis includes assessing market structure through higher highs, higher lows, lower highs, and lower lows, providing a framework to gauge the market's current state.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section id="team">
      <div class="container">
        <div class="section-title text-center">
          <div class="row">
            <p class="course-description mt-5">Don't miss out on the long-term potential of Forex trading. Incorporate our Weekly Mapping service into your trading strategy and gain a strategic advantage in the markets.</p>
          </div>
        </div>
      </div>
    </section>
<?= $this->include('default/footer') ?>