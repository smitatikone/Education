<?= $this->include('default/header') ?>
<?php //echo view('default/navbar', array('title' => 'Privacy Policy')); ?> 
    <section>
        <div class="container">
            <div class="section-content">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="text-center">Terms & Conditions</h1><br>
                        <p>These terms and conditions outline the rules and regulations for the use of the knowledgetradefx Website, located at <a data-fr-linked="true" href="//www.knowledgetradefx.in">www.knowledgetradefx.in</a>. If you continue using this website, we assume that you agree to these terms &amp; conditions along with other policies. We strictly advise you to not continue to use this website if you do not agree with any of the terms and conditions stated on this page. The following terminology applies to these Terms and Conditions: &ldquo;Client&rdquo;, &ldquo;You&rdquo;, &ldquo;Your&rdquo; and &ldquo;User&rdquo; refers to you, the person accessing this website or using our services. &ldquo;We&rdquo;, &ldquo;Our&rdquo;, &ldquo;Website&rdquo; is used collectively to represent us. &ldquo;Us&rdquo; refers to both you (client/users) and ourselves. These terms &amp; conditions are necessary for us to help us with the process of our assistance to the Client in the most appropriate manner for the express purpose of meeting the Client&rsquo;s needs in respect of the provision of our services, in accordance with all the applicable law.</p>
                        
                        <p>&nbsp;</p>
                        <h3>1. By continue using this website, you warrant and represent that &ndash;</h3>
                            <p><i class="fa fa-circle" aria-hidden="true"></i>   You are of legal age to enter into to form a binding Agreement in your jurisdiction.</p>
                            <p><i class="fa fa-circle" aria-hidden="true"></i>   You must not be barred from internet service anywhere.</p>
                            <p><i class="fa fa-circle" aria-hidden="true"></i>   The information/data you have provided are true &amp; valid.</p>
                            <p><i class="fa fa-circle" aria-hidden="true"></i>   You are not violating any of the laws while accessing our website or using any of our services.</p>
                        <p>&nbsp;</p>
                        <p><br></p>
                        <h3>2. You may use the website only for lawful purposes and in accordance with these terms and conditions and other policies. You agree not to use the website if:</h3>
                        <p><i class="fa fa-circle" aria-hidden="true"></i>    Your actions on this website violate this agreement and law including local, state, national, or international law.</p>
                        <p><i class="fa fa-circle" aria-hidden="true"></i>    Your action on our website may harm us, other users, and our website.</p>
                        <p><i class="fa fa-circle" aria-hidden="true"></i>    To transmit, or procure the sending of, any unsolicited or unauthorized advertising or promotional material or any other form of similar solicitation (spam).</p>
                        <p>&nbsp;</p>
                        <p><br></p>
                        <h3>3. Our liability:</h3>
                        <p>We and our associates disclaim all warranties, whether expressed or implied, including any warranty as to the quality, accuracy, and suitability of the information provided by you for any purpose. We or any of our team members are not responsible for any kind of loss or damage caused directly or indirectly to you while accessing our resources, website, or our services.</p>
                        
                        <p>&nbsp;</p>
                        
                        <h3>4. User&rsquo;s right:</h3>
                        <p>You are not permitted to use or copy any of the content available on this website. The content on this website belongs to us. However, the user submitting the user data/information will be held responsible for the data (if it violates any law including copyright) he/she is providing.</p>
                        
                        <p>&nbsp;</p>
                        <p><br></p>
                        <h3>5. User&rsquo;s data:</h3>
                        <p>We assure our users that their data will not be sold or shared with any third parties, those are not associated with the process in any way. While providing your data to us, you agree that we may use your data for providing our service(s) to you. While providing the data, you agree that all the data provided by you is true, valid, and updated. If you provide the wrong data, you may not be able to get the correct output. In any of such cases, we shall not be liable.</p>
                        <p><br></p>
                        <h3>6. Hyperlinks:</h3>
                        <h3>Linking to us:</h3>
                        <p><i class="fa fa-circle" aria-hidden="true"></i>     Any third party can link to us only if the link:</p>
                        <p><i class="fa fa-circle" aria-hidden="true"></i>     Is not in any way deceptive</p>
                        <p><i class="fa fa-circle" aria-hidden="true"></i>     Does not falsely imply sponsorship, endorsement or approval of the linking party and its products and/or services</p>
                        <p><i class="fa fa-circle" aria-hidden="true"></i>     Fits within the context of the linking party&rsquo;s site.</p>
                        <p><i class="fa fa-circle" aria-hidden="true"></i>     However, we have not held responsible if any suspicious site links to us.</p>
                        
                        <p><br></p>
                        <h3>We are linking to the third party:</h3>
                        <p>We may link to the third party as per our business process. If you click on the external link, you will be redirected to that site. We do not operate those external sites nor we are affiliated with them, so it is advised to read the policies of those external sites before taking any step on those websites. We are not responsible for those third-party websites. Thus, you(user) can&rsquo;t hold us responsible if any damage or loss occurs to you while using those external sites. By clicking on those external links, you agree that we are not liable for those sites.</p>
                        <p><br></p>
                        <h3>7. Payment</h3>
                        <p>We shall not take any responsibility or liability for malfunctioning or defects in any payment procedure. Payment of the Price shall be the sole responsibility of the User/Customer. By using our service you agree that you will pay our fees.</p>
                        
                        <p>&nbsp;</p>
                        <p><br></p>
                        <p>All the information displayed, transmitted or carried by knowledgetradefx and its subsidiaries (herein after called knowledgetradefx) including, but not limited to, news articles, opinions, reviews, text, photographs, images, illustrations, profiles, audio clips, video clips, trademarks, service marks and others (collectively the &ldquo;Content&rdquo;) on this knowledgetradefx&rsquo;s website is for informational purposes only.</p>
                        <p>These terms were last updated on 17/06/20.</p>
                    </div>
                <div>
            </div>
        <div>
    </section>
<?= $this->include('default/footer') ?>