<?= $this->include('default/header') ?>
<?php echo view('default/navbar', array('title' => 'testimonials')); ?> 

<!-- Start main-content -->
<div class="main-content">
    <!-- Section: inner-header -->
    <section class="inner-header divider layer-overlay overlay-theme-colored-7" data-bg-img="<?php echo base_url(); ?>public/assets/images/bg/bg1.jpg" style="background-image: url(&quot;<?php echo base_url(); ?>public/assets/images/bg/bg1.jpg&quot;);">
      <div class="container pt-120 pb-60">
        <!-- Section Content -->
        <div class="section-content">
          <div class="row"> 
            <div class="col-md-6">
              <h2 class="text-white font-36">Free Tools   </h2>
              <ol class="breadcrumb text-left mt-10 white">
                <li><a href="#">Home</a></li>
                <li class="active">Free Tools</li>
              </ol>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- <section>
      <div class="container">
        <div class="section-content">
          <div class="row">
            <div class="col-md-4">
              <div class="thumb">
                <img src="<?php echo base_url(); ?>public/assets/images/team/team-details.jpg" alt="">
              </div>
            </div>
            <div class="col-md-8">
            <div class="section-title text-center">
              <div class="row">
                <div class="col-md-12">
                  <h2 class="text-uppercase line-bottom-double-line-centered mt-0">Free <span class="text-theme-colored2">Tools</span></h2>
                  <p>To learn more about Forex Signals' tools and perform in-depth analysis, you can utilize the following tools:</p>
                </div>
              </div>
            </div>
              <h5 class="mt-5"><br></h5>
              <p>Welcome to our Free Tools page, where we showcase the real-life success stories of individuals who have embarked on a life-changing journey with our Forex Trading Institute. These are not just Free Tools; they are powerful narratives of transformation, perseverance, and triumph. Hear from our students as they share their experiences, challenges, and the profound impact our institute has had on their lives. Join us as we dive into the inspiring journeys of those who have unlocked their potential in the forex trading world.</p>
              
            </div>
          </div>
          
        </div>
      </div>
    </section> -->

    <section>
      <div class="container pt-70 pb-40">
        <div class="section-content">
        <div class="section-title text-center">
          <div class="row">
            <div class="col-md-12">
              <h2 class="text-uppercase line-bottom-double-line-centered mt-0">Free <span class="text-theme-colored2">Tools</span></h2>
              <p>To learn more about Forex Signals' tools and perform in-depth analysis, you can utilize the following tools:</p>
            </div>
          </div>
        </div>

          <div class="row multi-row-clearfix">
            <div class="col-sm-6 col-md-4">
              <article class="post clearfix campaign mb-30">
                <div class="entry-header">
                  <div class="post-thumb thumb"> 
                    <img src="<?php echo base_url(); ?>public/assets/images/testmonials/economic-calender.jpg" alt="" class="img-responsive img-fullwidth"> 
                  </div>    
                </div>
                <div class="entry-content p-20 bg-white">
                  <div class="entry-meta media mt-0 mb-10">
                    <div class="media-body pl-0">
                      <div class="event-content pull-left flip">
                        <h3 class="entry-title text-white text-uppercase m-0 mt-5"><a href="https://www.forexsignals.com/economic-calendar#start-reading">Economic Calendar</a></h3>
                        <!-- <span class="mb-10 text-gray-darkgray mr-10"><i class="fa fa-commenting-o mr-5 text-theme-colored"></i> 214 Comments</span>
                        <span class="mb-10 text-gray-darkgray mr-10"><i class="fa fa-heart-o mr-5 text-theme-colored"></i> 895 Likes</span> -->
                      </div>
                    </div>
                  </div>
                  <p class="mt-5">The economic calendar provides a list of upcoming events and economic indicators that can impact the Forex market. It helps you stay informed about important announcements and plan your trades accordingly.</p>
                </div>
              </article>
            </div>
            <div class="col-sm-6 col-md-4">
              <article class="post clearfix campaign mb-30">
                <div class="entry-header">
                  <div class="post-thumb thumb"> 
                    <img src="<?php echo base_url(); ?>public/assets/images/testmonials/lot-calculator.jpg" alt="" class="img-responsive img-fullwidth"> 
                  </div> 
                </div>
                <div class="entry-content p-20 bg-white">
                  <div class="entry-meta media mt-0 mb-10">
                    <div class="media-body pl-0">
                      <div class="event-content pull-left flip">
                        <h3 class="entry-title text-white text-uppercase m-0 mt-5"><a href="https://www.forexsignals.com/lot-size-calculator#use-tool">Lot Size Calculator</a></h3>
                        <!-- <span class="mb-10 text-gray-darkgray mr-10"><i class="fa fa-commenting-o mr-5 text-theme-colored"></i> 214 Comments</span>
                        <span class="mb-10 text-gray-darkgray mr-10"><i class="fa fa-heart-o mr-5 text-theme-colored"></i> 895 Likes</span>                       -->
                      </div>
                    </div>
                  </div>
                  <p class="mt-5">The lot size calculator helps you determine the appropriate lot size for your trade based on your risk tolerance and entry price. This tool allows you to manage your risk effectively.</p>
                </div>
              </article>
            </div>
            <div class="col-sm-6 col-md-4">
              <article class="post clearfix campaign mb-30">
                <div class="entry-header">
                  <div class="post-thumb thumb"> 
                    <img src="<?php echo base_url(); ?>public/assets/images/testmonials/profit-calculator.jpg" alt="" class="img-responsive img-fullwidth"> 
                  </div>  
                </div>
                <div class="entry-content p-20 bg-white">
                  <div class="entry-meta media mt-0 mb-10">
                    <div class="media-body pl-0">
                      <div class="event-content pull-left flip">
                        <h3 class="entry-title text-white text-uppercase font-weight-600 m-0 mt-5"><a href="https://www.forexsignals.com/profit-calculator#start-reading">Profit Calculator</a></h3>
                      </div>
                    </div>
                  </div>
                  <p class="mt-5">The profit calculator enables you to calculate the potential profit of a trade you are considering. By entering the relevant information, such as entry price, stop loss, and target price, you can assess the potential outcome of your trade.</p>
                </div>
              </article>
            </div>
            <div class="col-sm-6 col-md-4">
              <article class="post clearfix campaign mb-30">
                <div class="entry-header">
                  <div class="post-thumb thumb"> 
                    <img src="<?php echo base_url(); ?>public/assets/images/testmonials/pip-calculator.jpg" alt="" class="img-responsive img-fullwidth"> 
                  </div>                    
                </div>
                <div class="entry-content p-20 bg-white">
                  <div class="entry-meta media mt-0 mb-10">
                    <div class="media-body pl-0">
                      <div class="event-content pull-left flip">
                        <h3 class="entry-title text-white text-uppercase font-weight-600 m-0 mt-5"><a href="https://www.forexsignals.com/forex-trading-tools/pip-calculator#start-reading">Pip Calculator</a></h3>
                      </div>
                    </div>
                  </div>
                  <p class="mt-5">The pip calculator allows you to calculate the value of a pip in the currency you are trading. It helps you understand the potential profit or loss of a trade and manage your risk accordingly.</p>
                </div>
              </article>
            </div>
            <div class="col-sm-6 col-md-4">
              <article class="post clearfix campaign mb-30">
                <div class="entry-header">
                  <div class="post-thumb thumb"> 
                    <img src="<?php echo base_url(); ?>public/assets/images/testmonials/support-resistence.jpg" alt="" class="img-responsive img-fullwidth"> 
                  </div>  
                </div>
                <div class="entry-content p-20 bg-white">
                  <div class="entry-meta media mt-0 mb-10">
                    <div class="media-body pl-0">
                      <div class="event-content pull-left flip">
                        <h3 class="entry-title text-white text-uppercase m-0 mt-5"><a href="#">Support Resistance EA</a></h3>                      
                      </div>
                    </div>
                  </div>
                  <p class="mt-5">The Support Resistance Expert Advisor (EA) is a custom-built tool for MetaTrader 5 (MT5) that helps you identify and draw support and resistance levels on your chart. It streamlines the process and assists in making more accurate trading decisions.</p>
                </div>
              </article>
            </div>
            <div class="col-sm-6 col-md-4">
              <article class="post clearfix campaign mb-30">
                <div class="entry-header">
                  <div class="post-thumb thumb"> 
                    <img src="<?php echo base_url(); ?>public/assets/images/testmonials/margin-calculator.jpg" alt="" class="img-responsive img-fullwidth"> 
                  </div>  
                </div>
                <div class="entry-content p-20 bg-white">
                  <div class="entry-meta media mt-0 mb-10">
                    <div class="media-body pl-0">
                      <div class="event-content pull-left flip">
                        <h3 class="entry-title text-white text-uppercase m-0 mt-5"><a href="https://www.forexsignals.com/forex-trading-tools/forex-margin-calculator#start-reading">Forex Margin Calculator</a></h3>
                      </div>
                    </div>
                  </div>
                  <p class="mt-5">The Forex margin calculator helps you calculate the margin required to open and hold a trading position. It ensures you have sufficient funds in your account to support your trades and manage your margin effectively.</p>
                </div>
              </article>
            </div>
          </div>
        </div>
      </div>
    </section>

<?= $this->include('default/footer') ?>