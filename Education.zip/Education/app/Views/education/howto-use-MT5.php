<?= $this->include('default/header') ?>
<?php echo view('default/navbar', array('title' => 'education')); ?> 

 <!-- Start main-content -->
 <div class="main-content">
    <!-- Section: inner-header -->
    <section class="inner-header divider layer-overlay overlay-theme-colored-7" data-bg-img="<?php echo base_url(); ?>/public/assets/images/bg/bg1.jpg">
      <div class="container pt-120 pb-60">
        <!-- Section Content -->
        <div class="section-content">
          <div class="row"> 
            <div class="col-md-6">
              <h2 class="text-white font-36">How to use MT5? </h2>
              <ol class="breadcrumb text-left mt-10 white">
                <li><a href="#">Home</a></li>
                <li><a href="#">Education</a></li>
                <li class="active">How to use MT5? </li>
              </ol>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section id="team">
      <div class="container">
        <div class="section-title text-left">
          <div class="row">
            <div class="col-md-10 col-md-offset-1">
                <h4 class="line-bottom mt-0">How to use MT5? </h4>
                <p>To use MetaTrader 5 (MT5), a popular trading platform, follow these steps:</p>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section>
      <div class="container pt-70 pb-40">
        <div class="section-content">
          <div class="row multi-row-clearfix">
            <div class="col-sm-6 col-md-4">
              <article class="post clearfix campaign mb-30">
                <div class="entry-header">
                  <div class="post-thumb thumb"> 
                    <img src="http://localhost/Education/public/assets/images/blog/1.jpg" alt="" class="img-responsive img-fullwidth"> 
                  </div>    
                </div>
                <div class="entry-content p-20 bg-white">
                  <div class="entry-meta media mt-0 mb-10">
                    <div class="media-body pl-0">
                      <div class="event-content pull-left flip">
                        <h3 class="entry-title text-white text-uppercase m-0 mt-5"><a href="#">Download and Install MT5</a></h3>
                      </div>
                    </div>
                  </div>
                  <p class="mt-5">Visit the official website of a reputable broker that supports MT5 and download the platform. Install it on your computer or mobile device.</p>
                </div>
              </article>
            </div>
            <div class="col-sm-6 col-md-4">
              <article class="post clearfix campaign mb-30">
                <div class="entry-header">
                  <div class="post-thumb thumb"> 
                    <img src="http://localhost/Education/public/assets/images/blog/2.jpg" alt="" class="img-responsive img-fullwidth"> 
                  </div> 
                </div>
                <div class="entry-content p-20 bg-white">
                  <div class="entry-meta media mt-0 mb-10">
                    <div class="media-body pl-0">
                      <div class="event-content pull-left flip">
                        <h3 class="entry-title text-white text-uppercase m-0 mt-5"><a href="#">Account Registration</a></h3>
                      </div>
                    </div>
                  </div>
                  <p class="mt-5">: Open a trading account with a broker that offers MT5. Fill in the necessary information, provide the required documents for verification, and choose the account type that suits your trading needs.</p>
                </div>
              </article>
            </div>
            <div class="col-sm-6 col-md-4">
              <article class="post clearfix campaign mb-30">
                <div class="entry-header">
                  <div class="post-thumb thumb"> 
                    <img src="http://localhost/Education/public/assets/images/blog/3.jpg" alt="" class="img-responsive img-fullwidth"> 
                  </div>  
                </div>
                <div class="entry-content p-20 bg-white">
                  <div class="entry-meta media mt-0 mb-10">
                    <div class="media-body pl-0">
                      <div class="event-content pull-left flip">
                        <h3 class="entry-title text-white text-uppercase font-weight-600 m-0 mt-5"><a href="#">Login to MT5</a></h3>
                      </div>
                    </div>
                  </div>
                  <p class="mt-5">Launch the MT5 platform and enter your login credentials (username and password) provided by your broker. Select the appropriate server provided by your broker.</p>
                </div>
              </article>
            </div>
            <div class="col-sm-6 col-md-4">
              <article class="post clearfix campaign mb-30">
                <div class="entry-header">
                  <div class="post-thumb thumb"> 
                    <img src="http://localhost/Education/public/assets/images/blog/3.jpg" alt="" class="img-responsive img-fullwidth"> 
                  </div>                    
                </div>
                <div class="entry-content p-20 bg-white">
                  <div class="entry-meta media mt-0 mb-10">
                    <div class="media-body pl-0">
                      <div class="event-content pull-left flip">
                        <h3 class="entry-title text-white text-uppercase font-weight-600 m-0 mt-5"><a href="blog-single-left-sidebar.html">Familiarize Yourself with the Platform</a></h3>
                      </div>
                    </div>
                  </div>
                  <p class="mt-5">Take time to explore the platform's features and layout. Familiarize yourself with the various sections, such as Market Watch, Navigator, and Terminal.</p>
                </div>
              </article>
            </div>
            <div class="col-sm-6 col-md-4">
              <article class="post clearfix campaign mb-30">
                <div class="entry-header">
                  <div class="post-thumb thumb"> 
                    <img src="http://localhost/Education/public/assets/images/blog/2.jpg" alt="" class="img-responsive img-fullwidth"> 
                  </div>  
                </div>
                <div class="entry-content p-20 bg-white">
                  <div class="entry-meta media mt-0 mb-10">
                    <div class="media-body pl-0">
                      <div class="event-content pull-left flip">
                        <h3 class="entry-title text-white text-uppercase m-0 mt-5"><a href="#">Customizing the Workspace</a></h3>                      
                      </div>
                    </div>
                  </div>
                  <p class="mt-5">MT5 allows you to customize the platform to suit your preferences. You can adjust the chart settings, create customized templates, and arrange windows according to your trading style.</p>
                </div>
              </article>
            </div>
            <div class="col-sm-6 col-md-4">
              <article class="post clearfix campaign mb-30">
                <div class="entry-header">
                  <div class="post-thumb thumb"> 
                    <img src="http://localhost/Education/public/assets/images/blog/1.jpg" alt="" class="img-responsive img-fullwidth"> 
                  </div>  
                </div>
                <div class="entry-content p-20 bg-white">
                  <div class="entry-meta media mt-0 mb-10">
                    <div class="media-body pl-0">
                      <div class="event-content pull-left flip">
                        <h3 class="entry-title text-white text-uppercase m-0 mt-5"><a href="#">Adding Symbols</a></h3>
                      </div>
                    </div>
                  </div>
                  <p class="mt-5">In the Market Watch section, right-click and select "Symbols" to access the available trading instruments. Choose the desired currency pairs, stocks, commodities, or indices you want to trade and add them to the Market Watch.</p>
                </div>
              </article>
            </div>

            <div class="col-sm-6 col-md-4">
              <article class="post clearfix campaign mb-30">
                <div class="entry-header">
                  <div class="post-thumb thumb"> 
                    <img src="http://localhost/Education/public/assets/images/blog/1.jpg" alt="" class="img-responsive img-fullwidth"> 
                  </div>  
                </div>
                <div class="entry-content p-20 bg-white">
                  <div class="entry-meta media mt-0 mb-10">
                    <div class="media-body pl-0">
                      <div class="event-content pull-left flip">
                        <h3 class="entry-title text-white text-uppercase m-0 mt-5"><a href="#">Placing Trades</a></h3>
                      </div>
                    </div>
                  </div>
                  <p class="mt-5">To place a trade, right-click on the symbol in the Market Watch or select "New Order" from the toolbar. Specify the order type (market, pending, or stop), set the desired volume, and add any required stop-loss or take-profit levels. Review the order details and click "Buy" or "Sell" to execute the trade.</p>
                </div>
              </article>
            </div>
            <div class="col-sm-6 col-md-4">
              <article class="post clearfix campaign mb-30">
                <div class="entry-header">
                  <div class="post-thumb thumb"> 
                    <img src="http://localhost/Education/public/assets/images/blog/1.jpg" alt="" class="img-responsive img-fullwidth"> 
                  </div>  
                </div>
                <div class="entry-content p-20 bg-white">
                  <div class="entry-meta media mt-0 mb-10">
                    <div class="media-body pl-0">
                      <div class="event-content pull-left flip">
                        <h3 class="entry-title text-white text-uppercase m-0 mt-5"><a href="#">Using Charting Tools</a></h3>
                      </div>
                    </div>
                  </div>
                  <p class="mt-5">MT5 provides a wide range of charting tools and technical indicators for analysis. Open a chart by selecting a symbol from the Market Watch and dragging it onto the chart window. Customize the chart type, timeframes, and add indicators and drawing tools as needed.</p>
                </div>
              </article>
            </div>
            <div class="col-sm-6 col-md-4">
              <article class="post clearfix campaign mb-30">
                <div class="entry-header">
                  <div class="post-thumb thumb"> 
                    <img src="http://localhost/Education/public/assets/images/blog/1.jpg" alt="" class="img-responsive img-fullwidth"> 
                  </div>  
                </div>
                <div class="entry-content p-20 bg-white">
                  <div class="entry-meta media mt-0 mb-10">
                    <div class="media-body pl-0">
                      <div class="event-content pull-left flip">
                        <h3 class="entry-title text-white text-uppercase m-0 mt-5"><a href="#">Managing Trades</a></h3>
                      </div>
                    </div>
                  </div>
                  <p class="mt-5">In the Terminal section, you can monitor and manage your open positions, set stop-loss and take-profit levels, modify or close trades. You can also view your account balance, equity, margin, and transaction history.</p>
                </div>
              </article>
            </div>
            <div class="col-sm-6 col-md-4">
              <article class="post clearfix campaign mb-30">
                <div class="entry-header">
                  <div class="post-thumb thumb"> 
                    <img src="http://localhost/Education/public/assets/images/blog/1.jpg" alt="" class="img-responsive img-fullwidth"> 
                  </div>  
                </div>
                <div class="entry-content p-20 bg-white">
                  <div class="entry-meta media mt-0 mb-10">
                    <div class="media-body pl-0">
                      <div class="event-content pull-left flip">
                        <h3 class="entry-title text-white text-uppercase m-0 mt-5"><a href="#">Using Additional Features</a></h3>
                      </div>
                    </div>
                  </div>
                  <p class="mt-5">MT5 offers additional features such as Expert Advisors (automated trading systems), market news, economic calendar, and community chat. Explore these features to enhance your trading experience.</p>
                </div>
              </article>
            </div>
            
          </div>
          <div class="row">
            <div class="col-md-10 col-md-offset-1">
                <p>Remember, it's essential to practice and familiarize yourself with the platform using a demo account before trading with real money. This allows you to understand the platform's functionalities and test your trading strategies in a risk-free environment.</p>
            </div>
          </div>
        </div>
      </div>
    </section>

<?= $this->include('default/footer') ?>