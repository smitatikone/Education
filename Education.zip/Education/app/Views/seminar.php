<?= $this->include('default/header') ?>
<?php echo view('default/navbar', array('title' => 'session')); ?> 

<?= $this->include('default/footer') ?>