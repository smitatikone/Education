<?= $this->include('default/header') ?>
<?php //echo view('default/navbar', array('title' => 'Privacy Policy')); ?> 
<section>
      <div class="container">
        <div class="section-content">
          <div class="row">
            <div class="col-md-12">
              <h1 class="text-center">Privacy Policy</h1><br>
<p>Privacy &amp; Policy Your privacy is our priority. It is our policy to respect your privacy regarding the data/information we collect from you across our website which is located at www.knowledgetradefx.in. We collect it by fair and lawful means, with your knowledge and consent. We also let you know why we&rsquo;re collecting it and how it will be used.</p>

<p>The terms like &ldquo;We&rdquo;, &ldquo;Us&rdquo;, &ldquo;Our&rdquo;, &ldquo;website&rdquo; and &ldquo;knowledgetradefx&rdquo; are used collectively to represent the knowledgetradefx website and services.</p>

<p>You are free to refuse our privacy policy to collect your information/data, with the understanding that we will be unable to provide you with our services. However, Your continued use of our website will be regarded as an acceptance of our practices around privacy and personal information.</p>

<p>1.What data do we collect?</p>

<p>We only collect the data provided by the users with all their consent. These data are collected only to provide the service which we are offering. You have to provide information which is mandatory. Apart from this data, we also collect the &ldquo;cookies&rdquo; data. that means you don&rsquo;t provide us these details, it gets stored automatically when you visit our website. We may also use this data for analytics and marketing purposes.</p>

<p>The data that we automatically collect is:</p>

<p>Page flow, i.e., which page you (users) visit the most (navigational information) The action users take on the website IP address Operating system or browser you used for visiting our website Source of your entry to our website Your location Duration of your visit to our website Pages you have visited on our website We receive this above-mentioned information about you but we may or may not store this information. 2.How do we use your data?</p>

<p>User&rsquo;s data:</p>

<p>We only use your data for providing our service. We may use it to solve any issue or disputes users have while we are providing them any of our services. We can also have a record of your data and the service we provided.</p>

<p>Cookies and other data:</p>

<p>We use the cookies and other analytical data to help you in the following way:</p>

<p>To give you the most personalized user experience To make you have the easy login and tracking experience on our website To provide the relevant ads To understand what part of our website our users are most interested in. 3.Third-party cookies:</p>

<p>As we use some of the third party sites to help us with our services, we may use cookies (in some exceptional cases) provided by trusted third parties. The following section details which third party cookies you might encounter through this site:</p>

<p>This site uses Google Analytics which is one of the most trusted analytics solutions on the web for helping us to understand how the visitors/users use the website and ways that we can improve your experience. These cookies may track things such as how much time you spend on the website and the pages that you visit. We also use a third party payment gateway to proceed with the payment part. </p>

<p>As we can use these third-party cookies, you are required to read their own cookies policy on their official website. If you do not want us or any third party cookies to get stored on your website, you may change the setting in your browser.</p>

<p>Knowledgetradefx is committed to respecting the privacy of every personal who shares information or data with knowledgetradefx. Your privacy protection is important to us and we strive to take due care and protection of the information, we receive from you, the User. In this regard, we adhere to the various governing laws such as</p>

<p>The Information Technology Act, 2000 &ndash; Section 43A.</p>

<p>The Information Technology (Reasonable Security Practices and Procedures and Sensitive Personal Information) Rules, 2011. This Privacy Policy (&ldquo;Privacy Policy&rdquo;)</p>

<p>applies to the collection, storage, processing, disclosure and transfer of your Personal Information (defined below) as per the above mentioned laws, particularly when you use the website of https://knowledgetradefx.in (&ldquo;Website&rdquo;) operated by knowledgetradefx for any information or services (&ldquo;Services&rdquo;). The terms &lsquo;You&rsquo; or &lsquo;Your&rsquo; refer to you as the User (registered or unregistered) of the Website and/or Services and the terms &lsquo;We&rsquo;, &lsquo;Us&rsquo; and &lsquo;Our&rsquo; refer to KNOWLEDGETRADEFX.</p>

<p>Changes to the privacy policy:</p>

<p>The above-mentioned privacy policy can be changed or updated whenever needed. These privacy policies will not be changed as per the user&rsquo;s request. However, if you have any queries or feedback related to our privacy policy, you can write to us at info@knowledgetradefx.in</p>

<p>This privacy policy was last updated on 17/06/20.</p>

</div>
<div>
</div>
<div>
</section>
<?= $this->include('default/footer') ?>