<?php

namespace Config;

// Create a new instance of our RouteCollection class.
$routes = Services::routes();

/*
 * --------------------------------------------------------------------
 * Router Setup
 * --------------------------------------------------------------------
 */
$routes->setDefaultNamespace('App\Controllers');
$routes->setDefaultController('Home');
$routes->setDefaultMethod('index');
$routes->setTranslateURIDashes(false);
$routes->set404Override();
// The Auto Routing (Legacy) is very dangerous. It is easy to create vulnerable apps
// where controller filters or CSRF protection are bypassed.
// If you don't want to define all routes, please use the Auto Routing (Improved).
// Set `$autoRoutesImproved` to true in `app/Config/Feature.php` and set the following to true.
// $routes->setAutoRoute(false);

/*
 * --------------------------------------------------------------------
 * Route Definitions
 * --------------------------------------------------------------------
 */

// We get a performance increase by specifying the default
// route since we don't have to scan directories.
$routes->get('/', 'Home::index');
$routes->get('whyus', 'Home::whyus');
$routes->get('course', 'Home::course');
$routes->get('contact', 'Home::contact');

$routes->get('live_session', 'Home::live_session');
$routes->get('webinar', 'Home::webinar');
$routes->get('seminar', 'Home::seminar');
$routes->get('testimonials', 'Home::testimonials');

//Education
$routes->get('how-to-spot-a-forex-scam', 'Education::how_to_spot_a_forex_scam');
$routes->get('how-to-use-suport-and-resistance', 'Education::how_to_use_suport_and_resistance');
$routes->get('howto-use-MT5', 'Education::howto_use_MT5');
$routes->get('what-is-forex-fundamental-analysis', 'Education::what_is_forex_fundamental_analysis');
$routes->get('what-is-forex', 'Education::what_is_forex');
$routes->get('what-is-technical-analysis', 'Education::what_is_technical_analysis');
$routes->get('what-should-be-the-trading-psychology', 'Education::what_should_be_the_trading_psychology');
$routes->get('why-are-technical-indicators-important', 'Education::why_are_technical_indicators_important');

//Services
$routes->get('account-monitoring', 'Services::account_monitoring');
$routes->get('weekly-mapping', 'Services::weekly_mapping');
$routes->get('live-tecnical-analysis', 'Services::live_tecnical_analysis');
$routes->get('community-trading', 'Services::community_trading');

//Policy
$routes->get('privacy-policy', 'Home::privacy_policy');
$routes->get('terms-condition', 'Home::terms_condition');
$routes->get('refund-returnPolicy', 'Home::refund_returnPolicy');

/*
 * --------------------------------------------------------------------
 * Additional Routing
 * --------------------------------------------------------------------
 *
 * There will often be times that you need additional routing and you
 * need it to be able to override any defaults in this file. Environment
 * based routes is one such time. require() additional route files here
 * to make that happen.
 *
 * You will have access to the $routes object within that file without
 * needing to reload it.
 */
if (is_file(APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php')) {
    require APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php';
}
